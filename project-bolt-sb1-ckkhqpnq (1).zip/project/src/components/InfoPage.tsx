import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { InfoPageType } from '../types';

interface InfoPageProps {
  type: InfoPageType['type'];
  onBack: () => void;
}

const InfoPage: React.FC<InfoPageProps> = ({ type, onBack }) => {
  const getPageContent = () => {
    switch (type) {
      case 'about':
        return {
          title: 'About Elite Source',
          content: (
            <div className="space-y-8">
              <div>
                <p className="text-gray-300 leading-relaxed mb-4">
                  Elite Source was founded with a singular vision: to bring the world's most exclusive luxury fashion directly to discerning customers who appreciate exceptional quality and timeless elegance. Since our inception, we have curated an unparalleled collection of haute couture, designer ready-to-wear, and luxury accessories from the most prestigious fashion houses globally.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  Our commitment to excellence extends beyond our product selection. We believe that luxury shopping should be an experience that reflects the quality of the items we offer. Every piece in our collection is carefully selected by our team of fashion experts who understand the nuances of craftsmanship, design, and exclusivity.
                </p>
              </div>
              
              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Our Mission</h3>
                <p className="text-gray-300 leading-relaxed">
                  To democratize access to luxury fashion while maintaining the exclusivity and prestige that defines true luxury. We bridge the gap between the world's most coveted fashion pieces and customers who value authenticity, quality, and exceptional service.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Why Choose Us</h3>
                <ul className="space-y-3 text-gray-300">
                  <li className="flex items-start space-x-3">
                    <span className="w-2 h-2 bg-gold rounded-full mt-2 flex-shrink-0"></span>
                    <span>Authentic luxury pieces sourced directly from authorized retailers and fashion houses</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="w-2 h-2 bg-gold rounded-full mt-2 flex-shrink-0"></span>
                    <span>Expert curation ensuring only the finest quality and most coveted designs</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="w-2 h-2 bg-gold rounded-full mt-2 flex-shrink-0"></span>
                    <span>Personalized shopping experience with dedicated customer service</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="w-2 h-2 bg-gold rounded-full mt-2 flex-shrink-0"></span>
                    <span>Secure, white-glove delivery service for all purchases</span>
                  </li>
                </ul>
              </div>
            </div>
          )
        };

      case 'privacy':
        return {
          title: 'Privacy Policy',
          content: (
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Information We Collect</h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  We collect information you provide directly to us, such as when you create an account, make a purchase, or contact us for support. This includes your name, email address, shipping address, payment information, and communication preferences.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  We also automatically collect certain information about your device and how you interact with our website, including your IP address, browser type, pages visited, and time spent on our site.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">How We Use Your Information</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• Process and fulfill your orders</li>
                  <li>• Provide customer service and support</li>
                  <li>• Send you important updates about your orders</li>
                  <li>• Improve our website and services</li>
                  <li>• Protect against fraud and unauthorized access</li>
                </ul>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Data Security</h3>
                <p className="text-gray-300 leading-relaxed">
                  We implement industry-standard security measures to protect your personal information. All payment processing is handled through secure, encrypted channels, and we never store your complete payment information on our servers.
                </p>
              </div>
            </div>
          )
        };

      case 'terms':
        return {
          title: 'Terms of Service',
          content: (
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Acceptance of Terms</h3>
                <p className="text-gray-300 leading-relaxed">
                  By accessing and using Shop Elite Source, you accept and agree to be bound by the terms and provision of this agreement. These terms apply to all visitors, users, and others who access or use the service.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Product Information</h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  We strive to provide accurate product descriptions, images, and pricing. However, we do not warrant that product descriptions or other content is accurate, complete, reliable, current, or error-free.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  All products are subject to availability. We reserve the right to discontinue any product at any time without notice.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">User Accounts</h3>
                <p className="text-gray-300 leading-relaxed">
                  You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account.
                </p>
              </div>
            </div>
          )
        };

      case 'size-guide':
        return {
          title: 'Size Guide',
          content: (
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Women's Clothing</h3>
                <div className="overflow-x-auto">
                  <table className="w-full border border-gray-700 rounded-lg">
                    <thead className="bg-gray-800">
                      <tr>
                        <th className="px-4 py-3 text-left text-gold font-bold">Size</th>
                        <th className="px-4 py-3 text-left text-gold font-bold">Bust (inches)</th>
                        <th className="px-4 py-3 text-left text-gold font-bold">Waist (inches)</th>
                        <th className="px-4 py-3 text-left text-gold font-bold">Hips (inches)</th>
                      </tr>
                    </thead>
                    <tbody className="text-gray-300">
                      <tr className="border-t border-gray-700">
                        <td className="px-4 py-3">XS</td>
                        <td className="px-4 py-3">32-34</td>
                        <td className="px-4 py-3">24-26</td>
                        <td className="px-4 py-3">34-36</td>
                      </tr>
                      <tr className="border-t border-gray-700">
                        <td className="px-4 py-3">S</td>
                        <td className="px-4 py-3">34-36</td>
                        <td className="px-4 py-3">26-28</td>
                        <td className="px-4 py-3">36-38</td>
                      </tr>
                      <tr className="border-t border-gray-700">
                        <td className="px-4 py-3">M</td>
                        <td className="px-4 py-3">36-38</td>
                        <td className="px-4 py-3">28-30</td>
                        <td className="px-4 py-3">38-40</td>
                      </tr>
                      <tr className="border-t border-gray-700">
                        <td className="px-4 py-3">L</td>
                        <td className="px-4 py-3">38-40</td>
                        <td className="px-4 py-3">30-32</td>
                        <td className="px-4 py-3">40-42</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Men's Clothing</h3>
                <div className="overflow-x-auto">
                  <table className="w-full border border-gray-700 rounded-lg">
                    <thead className="bg-gray-800">
                      <tr>
                        <th className="px-4 py-3 text-left text-gold font-bold">Size</th>
                        <th className="px-4 py-3 text-left text-gold font-bold">Chest (inches)</th>
                        <th className="px-4 py-3 text-left text-gold font-bold">Waist (inches)</th>
                        <th className="px-4 py-3 text-left text-gold font-bold">Neck (inches)</th>
                      </tr>
                    </thead>
                    <tbody className="text-gray-300">
                      <tr className="border-t border-gray-700">
                        <td className="px-4 py-3">S</td>
                        <td className="px-4 py-3">34-36</td>
                        <td className="px-4 py-3">28-30</td>
                        <td className="px-4 py-3">14-14.5</td>
                      </tr>
                      <tr className="border-t border-gray-700">
                        <td className="px-4 py-3">M</td>
                        <td className="px-4 py-3">38-40</td>
                        <td className="px-4 py-3">32-34</td>
                        <td className="px-4 py-3">15-15.5</td>
                      </tr>
                      <tr className="border-t border-gray-700">
                        <td className="px-4 py-3">L</td>
                        <td className="px-4 py-3">42-44</td>
                        <td className="px-4 py-3">36-38</td>
                        <td className="px-4 py-3">16-16.5</td>
                      </tr>
                      <tr className="border-t border-gray-700">
                        <td className="px-4 py-3">XL</td>
                        <td className="px-4 py-3">46-48</td>
                        <td className="px-4 py-3">40-42</td>
                        <td className="px-4 py-3">17-17.5</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">How to Measure</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-gray-300">
                  <div>
                    <h4 className="font-bold text-white mb-2">Chest/Bust</h4>
                    <p>Measure around the fullest part of your chest/bust, keeping the tape measure level.</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-2">Waist</h4>
                    <p>Measure around your natural waistline, keeping the tape measure comfortably loose.</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-2">Hips</h4>
                    <p>Measure around the fullest part of your hips, approximately 8 inches below your waist.</p>
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-2">Neck</h4>
                    <p>Measure around the base of your neck where a shirt collar would sit.</p>
                  </div>
                </div>
              </div>
            </div>
          )
        };

      case 'shipping':
        return {
          title: 'Shipping Information',
          content: (
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Shipping Options</h3>
                <div className="space-y-4">
                  <div className="border border-gray-700 rounded-lg p-4">
                    <h4 className="font-bold text-white mb-2">Standard Delivery (5-7 Business Days)</h4>
                    <p className="text-gray-300">Free shipping on orders over $500. $25 for orders under $500.</p>
                  </div>
                  <div className="border border-gray-700 rounded-lg p-4">
                    <h4 className="font-bold text-white mb-2">Express Delivery (2-3 Business Days)</h4>
                    <p className="text-gray-300">$45 for all orders. Available for most locations.</p>
                  </div>
                  <div className="border border-gray-700 rounded-lg p-4">
                    <h4 className="font-bold text-white mb-2">White Glove Delivery (Next Day)</h4>
                    <p className="text-gray-300">$95 for premium handling and next-day delivery. Available in select cities.</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">International Shipping</h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  We ship worldwide to over 100 countries. International shipping rates are calculated at checkout based on destination and package weight. Delivery times vary by location but typically range from 7-14 business days.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  Please note that international customers may be responsible for customs duties and taxes imposed by their country's customs authority.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Order Processing</h3>
                <p className="text-gray-300 leading-relaxed">
                  Orders are processed Monday through Friday, excluding holidays. Orders placed after 2 PM EST will be processed the next business day. You will receive a confirmation email once your order has been shipped with tracking information.
                </p>
              </div>
            </div>
          )
        };

      case 'returns':
        return {
          title: 'Returns & Exchanges',
          content: (
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Return Policy</h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  We want you to be completely satisfied with your purchase. If for any reason you're not happy with your item, you may return it within 30 days of delivery for a full refund or exchange.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  Items must be in their original condition with all tags attached and in the original packaging. Custom or personalized items cannot be returned unless defective.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">How to Return</h3>
                <ol className="space-y-3 text-gray-300">
                  <li className="flex items-start space-x-3">
                    <span className="w-6 h-6 bg-gold text-black rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">1</span>
                    <span>Contact our customer service team to initiate a return</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="w-6 h-6 bg-gold text-black rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">2</span>
                    <span>Receive your prepaid return shipping label via email</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="w-6 h-6 bg-gold text-black rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">3</span>
                    <span>Package your item securely in the original packaging</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="w-6 h-6 bg-gold text-black rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">4</span>
                    <span>Drop off at any authorized shipping location</span>
                  </li>
                </ol>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Exchanges</h3>
                <p className="text-gray-300 leading-relaxed">
                  We offer free exchanges for size or color within 30 days of delivery. The exchange item must be of equal or lesser value. If the new item costs more, you'll be charged the difference.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gold mb-4">Refund Processing</h3>
                <p className="text-gray-300 leading-relaxed">
                  Once we receive your returned item, we'll inspect it and process your refund within 5-7 business days. Refunds will be credited to your original payment method.
                </p>
              </div>
            </div>
          )
        };

      default:
        return {
          title: 'Information',
          content: <p className="text-gray-300">Content not available.</p>
        };
    }
  };

  const { title, content } = getPageContent();

  return (
    <div className="pt-20 min-h-screen bg-black">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors duration-300 mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>

        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-2xl p-8">
          <h1 className="text-4xl font-bold text-white mb-8 tracking-wide">
            {title}
          </h1>
          {content}
        </div>
      </div>
    </div>
  );
};

export default InfoPage;